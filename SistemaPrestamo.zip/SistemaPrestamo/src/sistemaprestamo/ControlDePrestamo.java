/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprestamo;

/**
 *
 * @author sergi
 */
public class ControlDePrestamo {
    MenuPrestamoSolicitante solicitante;
    MenuPrestamoAdministrador administrador; 
    boolean estado;
    BaseD BD;
    
    public ControlDePrestamo(MenuPrestamoSolicitante solicitante,MenuPrestamoAdministrador admi,BaseD BD){
        estado=false;
        this.BD=BD;
        this.solicitante= solicitante;
        this.administrador= admi;
    }
    
    
    private String mostrarEstadoPrestamo(){
        estado=BD.getRegistrado();
        String mensaje="";
        if(estado==true){
            mensaje= "Registro Exitoso!, Matricula: "+solicitante.getMatricula()+ "\n"+ BD.getNoEncontrado();
            
        }else{
            mensaje= "Registro NO Exitoso!, Matricula: "+solicitante.getMatricula()+"\n"+ BD.getNoEncontrado() ;
        }
        return mensaje;
    }
    
    public void mandarNotificacion(){
        solicitante.setNotificacion(mostrarEstadoPrestamo());
        administrador.setNotificacion(mostrarEstadoPrestamo());    
    }
    
    public void mandarNotDevolucion(){
        solicitante.setNotificacionDev("\n Estado devolucion: "+BD.getDevolucionMaterial());
        administrador.setNotificacionDev("\n Estado devolucion: "+BD.getDevolucionMaterial());
       
    }
    
    
    public void DarBajaMaterial(){
        BD.darBaja(administrador.getMatriculaAlumnoD());
    }
    public MenuPrestamoSolicitante getSolicitante() {
        return solicitante;
    }

    public MenuPrestamoAdministrador getAdministrador() {
        return administrador;
    }

    public void setSolicitante(MenuPrestamoSolicitante solicitante) {
        this.solicitante = solicitante;
    }

    public void setAdministrador(MenuPrestamoAdministrador administrador) {
        this.administrador = administrador;
    }
}
