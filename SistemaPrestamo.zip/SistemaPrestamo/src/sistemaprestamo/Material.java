/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprestamo;

/**
 *
 * @author sergi
 */
public class Material {
    String nombre;
    int cantidad;
    String descripcion;
    String codigo;
    
   public Material(String nombre, int cantidad, String descripcion){
      this.nombre=nombre;
      this.cantidad=cantidad;
      this.descripcion=descripcion;
      
   }
    public Material(String nombre, String descripcion, String codigo){
      this.nombre=nombre;
      this.descripcion=descripcion;
      this.codigo=codigo;
   }
    public Material(String nombre, int cantidad, String descripcion, String codigo){
      this.nombre=nombre;
      this.codigo=codigo;
      this.descripcion=descripcion;
      this.codigo=codigo;
   }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Material{" + "nombre=" + nombre + ", cantidad=" + cantidad + ", descripcion=" + descripcion + '}';
    }
}
