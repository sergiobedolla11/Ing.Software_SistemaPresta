/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprestamo;

import java.util.ArrayList;

/**
 *
 * @author sergi
 */
public class SistemaPrestamo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Material material1 = new Material("cables caiman", " cables para fuente de poder","0006");
        Material material2 = new Material("Resistencia", "Resistencia de 1k", "0001");
        Material material3 = new Material("motor", "DC 12 v, 1100 RPM", "0002");
        Material material4 = new Material("fuente Poder", "Fuente", "0003");
        Material material5 = new Material("capacitor", "10 microF", "0004");
        Material material6 = new Material("Trnasistor", " ", "0005");
        
        ArrayList<Material> Materiales= new ArrayList();
        Materiales.add(material1);
        Materiales.add(material2);
        Materiales.add(material3);
        Materiales.add(material4);
        Materiales.add(material5);
        Materiales.add(material6);
        
        BaseD base= new BaseD(Materiales);
        
        // El alumno crea la solicitud del material
        MenuPrestamoSolicitante solicitante1= new MenuPrestamoSolicitante(1160);
        MenuPrestamoSolicitante solicitante2= new MenuPrestamoSolicitante(1170);
        solicitante1.solicitarMaterial("fuente Poder", 1, "par");
        solicitante2.solicitarMaterial("cables caiman", 1, "par");
        
        
        MenuPrestamoAdministrador administrador= new MenuPrestamoAdministrador();
        
        // la solicitud llega al control del prestamo.
        ControlDePrestamo control= new ControlDePrestamo( solicitante1, administrador, base);
        // el control del sistema manda a la base de datos la informacion de la solicitud
        base.registrarPrestamo(control.getSolicitante());
        // control manda tanto al menu de solicitante como al menun del administrador si se registro la solicitud y que materiales se encontraron
        control.mandarNotificacion();
        
        // muestra las notificaciones si se realizo el registro exitoso
        administrador.mostrarNotificacionAdministrador();
        solicitante1.mostrarNotificacionSolicitante();
        
        
        control.setSolicitante(solicitante2);
        // el control del sistema manda a la base de datos la informacion de la solicitud
        base.registrarPrestamo(control.getSolicitante());
        // control manda tanto al menu de solicitante como al menun del administrador si se registro la solicitud y que materiales se encontraron
        control.mandarNotificacion();
        solicitante2.mostrarNotificacionSolicitante();
        // muestra las notificaciones si se realizo el registro exitoso
        administrador.mostrarNotificacionAdministrador();
 
        //Mostrar cantidad de registro
        System.out.println("Verificar cantidad de usuarios registrados\n");
        System.out.println(base.tamañoPrestamoRegistrada());
       
        administrador.devolucionMaterial(1160);
        control.DarBajaMaterial(); 
        //Manda la notificacion a los menu del solicitante y administrador
        control.mandarNotDevolucion();
        
        System.out.println("Estado Devolución\n");
        solicitante2.mostrarNotDevolucion();
        administrador.mostrarNotDevolucion();
        
        //Mostrar cantidad de registro
        System.out.println(base.tamañoPrestamoRegistrada());
    }
    
}
