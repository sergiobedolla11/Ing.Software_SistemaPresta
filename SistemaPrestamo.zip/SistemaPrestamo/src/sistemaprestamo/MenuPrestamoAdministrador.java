/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprestamo;

/**
 *
 * @author sergi
 */
public class MenuPrestamoAdministrador {
    String notificacion; 
    String notificacionDev;
    int matriculaAlumnoD;
    
    public MenuPrestamoAdministrador(){
        notificacion=" ";
        notificacionDev= " ";
    }
    public String getNotificacion() {
        return notificacion;
    }

    public void setNotificacion(String notificacion) {
        this.notificacion = notificacion;
    }
    
    public void mostrarNotificacionAdministrador(){
        System.out.println("Menú Administrador: "+notificacion+ "\n");
    }
    
    public void mostrarNotDevolucion(){
        System.out.println("Menú Administrador: "+ notificacionDev+ "\n" );
    }
    
    public void devolucionMaterial(int matricula){
       matriculaAlumnoD=matricula;
    }

    public int getMatriculaAlumnoD() {
        return matriculaAlumnoD;
    }

    public String getNotificacionDev() {
        return notificacionDev;
    }

    public void setNotificacionDev(String notificacionDev) {
        this.notificacionDev = notificacionDev;
    }
    
}
