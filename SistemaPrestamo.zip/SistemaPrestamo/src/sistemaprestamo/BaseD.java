/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprestamo;

import java.util.ArrayList;

/**
 *
 * @author sergi
 */
public class BaseD {
    ArrayList<Material>almacenMaterial;
    ArrayList<MenuPrestamoSolicitante>prestamo;
    boolean registrado;
    String noEncontrado;
    String devolucionMaterial;
    
    public BaseD(ArrayList<Material> almacenMaterial){
        this.almacenMaterial=almacenMaterial;
        prestamo=new ArrayList();
        registrado=false;
        devolucionMaterial=" ";
    }
    public void agregarMateriaAlmacen(String nombre, int cantidad, String descripcion, String codigo){
        almacenMaterial.add(new Material(nombre, cantidad, descripcion, codigo));
    }
    
    public void registrarPrestamo(MenuPrestamoSolicitante solicitante){
        
       noEncontrado="No disponible: ";
       int cont=0;
       for(int i=0; i<=solicitante.getSolicitud().size()-1;i++){
           for(int a=0; a<=almacenMaterial.size()-1;a++){
               if(!almacenMaterial.get(a).getNombre().equals(solicitante.getSolicitud().get(i).getNombre())&&a>=almacenMaterial.size()-1){
                   noEncontrado+=solicitante.getSolicitud().get(i).getNombre() +", ";
               }else
                if(almacenMaterial.get(a).getNombre().equals(solicitante.getSolicitud().get(i).getNombre())){
                   cont++;
               }
           }
       }
       if(cont==solicitante.getSolicitud().size()){
           setRegistrado(true);
           prestamo.add(solicitante);
           noEncontrado=" ";
       }else if(cont>1){
           setRegistrado(true);
           prestamo.add(solicitante);
       }
       
    }
    
    public void darBaja(int matricula){
        int cont=0;
        boolean encontrado=false;
        for(int i = 0; i <= prestamo.size()-1; i++) {
                if(prestamo.get(i).getMatricula()==matricula){
                    prestamo.remove(i);
                    encontrado=true;
                } 
        }
        if(encontrado==true){
            devolucionMaterial="Exitosa";
        }else{
            devolucionMaterial="No se encontro la Matricula";
        }
       
    }
    public ArrayList<Material> getAlmacenMaterial() {
        return almacenMaterial;
    }

    public void setAlmacenMaterial(ArrayList<Material> almacenMaterial) {
        this.almacenMaterial = almacenMaterial;
    }

    public boolean getRegistrado() {
        return registrado;
    }

    public void setRegistrado(boolean registrado) {
        this.registrado = registrado;
    }

    public String getNoEncontrado() {
        return noEncontrado;
    }

    public String getDevolucionMaterial() {
        return devolucionMaterial;
    }
    
    
    public int tamañoPrestamoRegistrada(){
    return prestamo.size();
}
}
