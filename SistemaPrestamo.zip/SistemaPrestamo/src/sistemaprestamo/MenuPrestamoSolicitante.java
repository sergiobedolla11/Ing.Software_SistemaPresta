/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprestamo;

import java.util.ArrayList;

/**
 *
 * @author sergi
 */
public class MenuPrestamoSolicitante {
    ArrayList<Material>materiales;
    int matricula;
    String notificacion;
    String notificacionDev;
    
    public MenuPrestamoSolicitante(int matricula){
       this.matricula=matricula;
       materiales= new ArrayList(); 
       notificacion=null;
    }
     
    
    public void solicitarMaterial(String nombreMaterial, int cantidad, String descripcion){
        materiales.add(new Material(nombreMaterial, cantidad, descripcion));

    }
    
     public void mostrarNotDevolucion(){
        System.out.println("Menú Solicitante: "+ notificacionDev+ "\n" );
    }
     
    public ArrayList<Material> getSolicitud() {
        return materiales;
    }
    public int getMatricula(){
        return matricula;
    }
    

    public String getNotificacion() {
        return notificacion;
    }

    public void setNotificacion(String notificacion) {
        this.notificacion = notificacion;
    }
    
    public void mostrarNotificacionSolicitante(){
        System.out.println("Menú Solicitante: "+notificacion+"\n");
    }

    public String getNotificacionDev() {
        return notificacionDev;
    }

    public void setNotificacionDev(String notificacionDev) {
        this.notificacionDev = notificacionDev;
    }
}
